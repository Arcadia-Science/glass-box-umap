"""Download British Museum photographs for the axes plotted on the UMAP.

Each axe's catalogue accession is resolved to its primary photograph through
the British Museum search API, which returns the object's type and media path
directly. Only a hit whose unique object id matches the registration and whose
type is an axe is accepted, so same-numbered objects in other departments
(plaques, vessels, moulds) are never mistaken for the axe. Images come from the
open media CDN. Every request is a plain HTTP call through a browser-
impersonating client. No browser is launched or driven.
"""

import json
import re
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from urllib.parse import quote

import pandas as pd
import typer
from curl_cffi import requests as creq

app = typer.Typer(pretty_exceptions_enable=False)

KEEP_ELEMENTS: list[str] = ["Cu", "Sn", "As", "Sb", "Pb", "Ag", "Ni", "Fe", "Co", "Bi"]
DROP_FLAGS: set[str] = {"PersistentHarmonisationProblem", "CorrosionProductOnly"}
OBJECT_URL = "https://www.britishmuseum.org/collection/object/{slug}"
SEARCH_URL = "https://www.britishmuseum.org/api/_search?keyword="
MEDIA_CDN = "https://media.britishmuseum.org/media/"
AXE_TYPES = re.compile(r"axe|palstave|celt|chisel|socketed|adze", re.IGNORECASE)


@dataclass
class Result:
    ArtefactID: int
    MusAcc: str
    slug: str
    object_url: str
    status: str
    image_url: str
    local_path: str


def plotted_bm_axes(data_dir: Path) -> pd.DataFrame:
    """Return the British Museum subset of the axes that appear on the UMAP."""
    elem = pd.read_csv(data_dir / "ADS_earlyaxes_elemental.tsv", sep="\t", low_memory=False)
    main = pd.read_csv(data_dir / "ADS_earlyaxes_main.tsv", sep="\t", low_memory=False)
    for col in KEEP_ELEMENTS:
        elem[col] = pd.to_numeric(elem[col], errors="coerce")
    flagged = elem["AnalysisFlags"].fillna("").apply(lambda s: any(flag in s for flag in DROP_FLAGS))
    elem = elem.loc[~flagged].dropna(subset=KEEP_ELEMENTS)
    plotted = list(elem["ArtefactID"])
    sub = main[main["ArtefactID"].isin(plotted)].drop_duplicates(subset=["ArtefactID"])  # type: ignore[call-overload]
    bm = sub[sub["MusAcc"].fillna("").str.contains("British Museum")]
    return pd.DataFrame(bm)


def bm_slug(mus_acc: str) -> str:
    """Map a British Museum accession to its object-page slug (for browsing)."""
    acc = mus_acc.split(":", 1)[1].strip() if ":" in mus_acc else mus_acc.strip()
    prefixed = re.match(r"^(WG|SL|TC)\.?\s*(\d+\w*)$", acc, re.IGNORECASE)
    if prefixed:
        return f"H_{prefixed.group(1).upper()}-{prefixed.group(2)}"
    registered = re.match(r"^(\d{4}),(\d{3,4})\.(\d+)([a-z]*)$", acc, re.IGNORECASE)
    if registered:
        year, month_day, number, suffix = registered.groups()
        item = f"{number}-{suffix}" if suffix else number
        return f"H_{year}-{month_day}-{item}"
    return ""


def clean_accession(mus_acc: str) -> str:
    """Reduce a museum accession string to its bare British Museum registration."""
    acc = mus_acc.split(":", 1)[1] if ":" in mus_acc else mus_acc
    acc = acc.split(";")[0]
    return re.sub(r"\s*\(.*?\)", "", acc).strip()


def search_keyword(accession: str) -> str:
    """Drop a sub-item suffix so the search index matches the parent registration."""
    return re.sub(r"(\.\d+)[a-z].*", r"\1", accession)


def expected_uid(accession: str) -> str:
    """Predict the British Museum unique object id prefix for a registration."""
    prefixed = re.match(r"^(WG|SL|TC)\.?\s*(\d+)", accession, re.IGNORECASE)
    if prefixed:
        return f"H_{prefixed.group(1).upper()}-{prefixed.group(2)}"
    registered = re.match(r"^(\d{4}),(\d{3,4})\.(\d+)([a-z]?)", accession, re.IGNORECASE)
    if registered:
        year, month_day, number, suffix = registered.groups()
        return f"H_{year}-{month_day}-{number}-{suffix}" if suffix else f"H_{year}-{month_day}-{number}"
    return ""


def get_with_retries(url: str, impersonate: bool, retries: int = 3) -> creq.Response:
    """Fetch a url, retrying with backoff on transient network failures."""
    last: Exception = RuntimeError("no attempt made")
    for attempt in range(retries):
        try:
            if impersonate:
                return creq.get(url, impersonate="chrome", timeout=40)
            return creq.get(url, timeout=60, verify=False)
        except creq.exceptions.RequestException as exc:
            last = exc
            time.sleep(2.0 * (attempt + 1))
    raise last


def resolve_image(mus_acc: str) -> str:
    """Resolve an accession to its axe photograph through the search API.

    Accepts only a hit whose unique object id matches the registration and whose
    object type is an axe, so a same-numbered plaque, vessel, or mould is never
    returned in place of the axe.
    """
    accession = clean_accession(mus_acc)
    keyword = search_keyword(accession)
    target = expected_uid(accession)
    if not keyword or not target:
        return ""
    try:
        data = get_with_retries(SEARCH_URL + quote(keyword), True).json()
    except (creq.exceptions.RequestException, ValueError):
        return ""

    for hit in data.get("hits", {}).get("hits", []):
        source = hit.get("_source", {})
        uid = next(
            (i.get("value", "") for i in source.get("identifier") or [] if i.get("type") == "unique object id"),
            "",
        )
        if not (uid.startswith(target) and not uid[len(target) : len(target) + 1].isdigit()):
            continue
        if not AXE_TYPES.search(json.dumps(source.get("name", ""))):
            continue
        media = source.get("multimedia") or []
        if not media:
            continue
        location = media[0].get("@processed", {}).get("preview", {}).get("location")
        if location:
            return MEDIA_CDN + location
    return ""


def download_image(image_url: str, dest: Path) -> str:
    """Download the best available size of a CDN image, returning the saved url."""
    base, name = image_url.rsplit("/", 1)
    for size in ("large_", "mid_", "preview_"):
        url = base + "/" + re.sub(r"^(preview|mid|large|max)_", size, name)
        r = get_with_retries(url, False)
        if r.status_code == 200 and r.content:
            dest.write_bytes(r.content)
            return url
    return ""


@app.command()
def main(
    data_dir: Path = Path(__file__).parent / "data",
    out_dir: Path = Path(__file__).parent / "assets" / "axe_photos",
    manifest: Path = Path(__file__).parent / "assets" / "bm_image_manifest.csv",
    delay: float = 0.4,
    limit: int = 0,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    axes = plotted_bm_axes(data_dir)
    if limit:
        axes = axes.head(limit)
    typer.echo(f"British Museum axes on the UMAP: {len(axes)}")

    results: list[Result] = []
    for _, row in axes.iterrows():
        artefact_id = int(row["ArtefactID"])
        mus_acc = str(row["MusAcc"])
        slug = bm_slug(mus_acc)
        object_url = OBJECT_URL.format(slug=slug) if slug else ""
        dest = out_dir / f"{artefact_id}.jpg"

        if dest.exists():
            results.append(Result(artefact_id, mus_acc, slug, object_url, "downloaded", "", str(dest)))
            continue

        try:
            image_url = resolve_image(mus_acc)
        except creq.exceptions.RequestException:
            image_url = ""
        if not image_url:
            results.append(Result(artefact_id, mus_acc, slug, object_url, "no_image", "", ""))
            typer.echo(f"  {artefact_id}  no_image  {mus_acc}")
            time.sleep(delay)
            continue

        try:
            saved_url = download_image(image_url, dest)
        except creq.exceptions.RequestException:
            saved_url = ""
        status = "downloaded" if saved_url else "download_error"
        results.append(Result(artefact_id, mus_acc, slug, object_url, status, saved_url, str(dest) if saved_url else ""))
        typer.echo(f"  {artefact_id}  {status}  {slug or mus_acc}")
        time.sleep(delay)

    frame = pd.DataFrame([asdict(r) for r in results])
    frame.to_csv(manifest, index=False)
    counts = frame["status"].value_counts().to_dict()
    typer.echo(f"\nwrote {manifest}")
    typer.echo(f"status: {counts}")


if __name__ == "__main__":
    app()
