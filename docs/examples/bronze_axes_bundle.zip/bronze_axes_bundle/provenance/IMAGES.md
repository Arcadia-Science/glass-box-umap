# Axe images: how they were obtained and matched

## Goal

Attach a photograph of each axe to its point on the Glass Box UMAP, keyed by `ArtefactID`, so the interactive plot can show the actual object on hover.

## Where photographs come from

The dataset's own `URL` field links to scanned museum record cards (line drawings with handwritten measurements), not photographs. The open aggregators (Wikimedia Commons, Europeana, the MicroPasts 3D models on Sketchfab) carry essentially none of these specific catalogued objects. They hold Portable Antiquities Scheme metal-detector finds, which are a different population.

The photographs come from the holding museums' own online collections. The British Museum holds the largest share (207 of the 539 plotted axes), and after it a long tail of other institutions. Each museum exposes a different catalogue, so each needs its own recipe to turn an accession number into an image. Every request is a plain HTTP call through a browser-impersonating client (`curl_cffi`). No browser is launched or driven.

## Results

| Holder | Axes | With photo |
| --- | --- | --- |
| British Museum | 207 | 121 (58%) |
| Ashmolean Museum, Oxford | 18 | 14 (78%) |
| National Museum Wales | 35 | 8 (23%) |
| Cambridge Museum of Archaeology and Anthropology | 38 | 8 (21%) |
| All plotted axes | 539 | 149 (28%) |

The remaining axes are spread across smaller museums (Norwich, Carisbrooke, Lincoln, Salisbury, and many others) and private owners, which have no accessible online imagery, plus the records at the museums above that simply carry no photograph.

## How each museum is resolved

The British Museum is resolved through its internal search API (reached with Chrome TLS impersonation, since the site is behind Cloudflare). A query for the registration returns candidate records carrying their unique object id, object type, and media path. We accept only a record whose id matches the registration and whose type is an axe, then download its image from the open media CDN (`media.britishmuseum.org`) at the `large_` size, falling back to `mid_` then `preview_`. The object-type check is essential: BM registration numbers recur across departments, so a bare object-page slug like `H_1981-0702-2` can land on a same-numbered plaque, vase, or casting mould. Matching on type as well as id keeps those non-axe objects out.

The Ashmolean exposes a JSON search API. A query for `AN<accession>` returns the record, whose `multimedia[0].resourceSpaceId` feeds a IIIF image URL (`dams.ashmus.ox.ac.uk/iiif/image/<id>/full/max/0/default.jpg`). This is the cleanest and highest-yield source.

National Museum Wales is searched by its accession field, which returns a single object page. If that page embeds a `data-id="dams_<uuid>"` it has a photograph, served from `museum.wales/media-dams/<uuid>/mid/`.

Cambridge MAA is searched by accession through its object browser. Results are filtered to the card whose displayed accession matches exactly (the search is a substring match, so `1903.155` also returns unrelated objects), and the object page links the full-size image under `/media/library_images/web/`.

## Matching confidence

For the British Museum, every image is matched by exact unique object id and confirmed to be an axe by object type, and many also carry the registration in the image filename as an independent check. An earlier slug-based approach was retired after it mistook a handful of same-numbered non-axe objects (a plaque, a vase, a ritual collar, a mould) for their axes; the type filter closes that off. For the other museums, the Ashmolean match is verified by the accession embedded in the image identifier (and the photographs often have the accession inked on the object, for example `1927.2365`), while National Museum Wales and Cambridge are matched by exact accession in the catalogue search.

The main limitation is group plates. A meaningful minority of images, more so at the museums than the BM, show several axes from one find or hoard photographed together. The axe is present in its assigned image but is not always isolated.

## Files

`fetch_bm_images.py` fetches the British Museum photographs (search API, accepting only axe-typed records whose id matches the registration). `fetch_other_museum_images.py` fetches the Ashmolean, National Museum Wales, and Cambridge photographs, one resolver per museum. The photographs land in `assets/axe_photos/{ArtefactID}.jpg`. Status per axe is recorded in `assets/bm_image_manifest.csv` and `assets/other_museum_manifest.csv`, and `assets/axes_without_photos.csv` lists the axes still lacking a photo with a lookup URL where one exists. The notebook reads from `assets/axe_photos/` and embeds each photo as a base64 thumbnail in the interactive plot's hover.

## Reproducing

Run `python fetch_bm_images.py` and `python fetch_other_museum_images.py` from the `bronze_axes` directory. Each rebuilds the plotted set from the raw catalogue TSVs, resolves its museums' accessions to images, and writes the photographs and a manifest. Files already present are skipped, so re-running only fills gaps.
