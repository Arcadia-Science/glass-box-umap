"""Download axe photographs from non-British-Museum collections.

Each holding museum exposes a different catalogue, so an accession is resolved
to an image through a per-museum recipe (Ashmolean JSON API, National Museum
Wales collections search, Cambridge MAA object search). Every request is a plain
HTTP call through a browser-impersonating client. No browser is launched or
driven. Photographs land in the shared asset directory keyed by ArtefactID.
"""

import html
import re
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from urllib.parse import quote

import pandas as pd
import typer
from curl_cffi import requests as creq

app = typer.Typer(pretty_exceptions_enable=False)

KEEP_ELEMENTS: list[str] = ["Cu", "Sn", "As", "Sb", "Pb", "Ag", "Ni", "Fe", "Co", "Bi"]
DROP_FLAGS: set[str] = {"PersistentHarmonisationProblem", "CorrosionProductOnly"}
ASHMOLEAN_API = "https://prd-online.glamdigital.io/v2/search/ash/catalogue"
ASHMOLEAN_KEY = "yuFn5KEdcU2KVtUFol2Ft24wonNthuDBaovxyN8h"
MIN_IMAGE_BYTES = 3000


@dataclass
class Result:
    ArtefactID: int
    museum: str
    accession: str
    status: str
    image_url: str
    local_path: str


def plotted_axes(data_dir: Path) -> pd.DataFrame:
    """Rebuild the per-artefact table of axes that appear on the UMAP."""
    elem = pd.read_csv(data_dir / "ADS_earlyaxes_elemental.tsv", sep="\t", low_memory=False)
    main = pd.read_csv(data_dir / "ADS_earlyaxes_main.tsv", sep="\t", low_memory=False)
    for col in KEEP_ELEMENTS:
        elem[col] = pd.to_numeric(elem[col], errors="coerce")
    flagged = elem["AnalysisFlags"].fillna("").apply(lambda s: any(f in s for f in DROP_FLAGS))
    elem = elem.loc[~flagged].dropna(subset=KEEP_ELEMENTS)
    plotted = list(elem["ArtefactID"])
    sub = main[main["ArtefactID"].isin(plotted)].drop_duplicates(subset=["ArtefactID"])  # type: ignore[call-overload]
    return pd.DataFrame(sub)


def accession_of(mus_acc: str) -> str:
    """Strip a museum accession string to its bare accession number."""
    acc = mus_acc.split(":", 1)[1] if ":" in mus_acc else mus_acc
    acc = acc.split(";")[0]
    return re.sub(r"\s*\(.*?\)", "", acc).strip()


def get(url: str, headers: dict[str, str] | None = None) -> creq.Response:
    return creq.get(url, headers=headers, impersonate="chrome", timeout=30, verify=False)


def resolve_ashmolean(accession: str) -> str:
    """Resolve an Ashmolean dotted accession to its largest IIIF image url."""
    parsed = re.match(r"^(\d{4})\.(\d+)$", accession)
    if not parsed:
        return ""
    year, number = parsed.group(1), int(parsed.group(2))
    url = f"{ASHMOLEAN_API}?q=AN{quote(accession)}&from=0&size=5"
    data = get(url, {"x-api-key": ASHMOLEAN_KEY, "Content-Type": "application/json"}).json()
    for hit in data.get("results", []):
        media = hit.get("item", {}).get("multimedia") or []
        if not media:
            continue
        identifier = media[0].get("identifier", "")
        embedded = re.search(r"AN(\d{4})\.0*(\d+)", identifier)
        if not embedded or embedded.group(1) != year or int(embedded.group(2)) != number:
            continue
        resource_id = media[0].get("resourceSpaceId")
        if resource_id:
            return f"https://dams.ashmus.ox.ac.uk/iiif/image/{resource_id}/full/max/0/default.jpg"
    return ""


def resolve_nmw(accession: str) -> str:
    """Resolve a National Museum Wales accession to its largest image url."""
    search = f"https://museum.wales/collections/online/?field0=accession&value0={quote(accession)}&index=-12"
    page = get(search).text
    obj = re.search(r"/collections/online/object/[0-9a-f\-]{36}/[^/?\"]+/", page)
    if not obj:
        return ""
    record = get("https://museum.wales" + obj.group(0)).text
    dams = re.findall(r'data-id="dams_([0-9a-f\-]{36})"', record)
    if not dams:
        return ""
    return f"https://museum.wales/media-dams/{dams[0]}/mid/"


def resolve_maa(accession: str) -> str:
    """Resolve a Cambridge MAA accession to its largest image url."""
    advanced = '[{"field":"accession","value":"%s"}]' % accession
    page = get("https://collections.maa.cam.ac.uk/objects/?advanced_search=" + quote(advanced)).text
    cards = re.findall(r'href="(\d+)\?advanced_search=[^"]*">([^<]+)</a>', page)
    object_id = next((cid for cid, text in cards if html.unescape(text).strip() == accession), "")
    if not object_id:
        return ""
    record = get(f"https://collections.maa.cam.ac.uk/objects/{object_id}").text
    image = re.search(r'href="(/media/library_images/web/[^"]+)"', record)
    if not image:
        return ""
    return "https://collections.maa.cam.ac.uk" + image.group(1)


RESOLVERS = {"OXFAS": resolve_ashmolean, "NMW": resolve_nmw, "CAMAA": resolve_maa}


def museum_code(mus_acc: str) -> str:
    return next((code for code in RESOLVERS if code in mus_acc), "")


def download(image_url: str, dest: Path) -> bool:
    r = get(image_url)
    if r.status_code != 200 or len(r.content) < MIN_IMAGE_BYTES:
        return False
    dest.write_bytes(r.content)
    return True


@app.command()
def main(
    data_dir: Path = Path(__file__).parent / "data",
    out_dir: Path = Path(__file__).parent / "assets" / "axe_photos",
    manifest: Path = Path(__file__).parent / "assets" / "other_museum_manifest.csv",
    delay: float = 0.4,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    axes = plotted_axes(data_dir)
    axes = axes[axes["MusAcc"].fillna("").apply(museum_code).astype(bool)]
    typer.echo(f"axes held by supported museums (Ashmolean, NMW, Cambridge MAA): {len(axes)}")

    results: list[Result] = []
    for _, row in axes.iterrows():
        artefact_id = int(row["ArtefactID"])
        mus_acc = str(row["MusAcc"])
        code = museum_code(mus_acc)
        accession = accession_of(mus_acc)
        dest = out_dir / f"{artefact_id}.jpg"

        if dest.exists():
            results.append(Result(artefact_id, code, accession, "downloaded", "", str(dest)))
            continue

        try:
            image_url = RESOLVERS[code](accession)
        except (creq.exceptions.RequestException, ValueError):
            image_url = ""
        if not image_url:
            results.append(Result(artefact_id, code, accession, "no_image", "", ""))
            typer.echo(f"  {artefact_id}  {code}  no_image  {accession}")
            time.sleep(delay)
            continue

        try:
            ok = download(image_url, dest)
        except creq.exceptions.RequestException:
            ok = False
        status = "downloaded" if ok else "download_error"
        results.append(Result(artefact_id, code, accession, status, image_url if ok else "", str(dest) if ok else ""))
        typer.echo(f"  {artefact_id}  {code}  {status}  {accession}")
        time.sleep(delay)

    frame = pd.DataFrame([asdict(r) for r in results])
    frame.to_csv(manifest, index=False)
    typer.echo(f"\nwrote {manifest}")
    typer.echo(f"status by museum:\n{frame.groupby('museum')['status'].value_counts()}")


if __name__ == "__main__":
    app()
