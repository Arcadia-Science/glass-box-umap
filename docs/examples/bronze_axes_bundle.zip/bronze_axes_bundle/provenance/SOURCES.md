# Sources, licences, and credits

This bundle accompanies the Glass Box UMAP "British Bronze Age axes" example. It contains a measurement dataset, a set of object photographs, and the provenance records that tie one to the other. Everything bundled here is redistributable for non-commercial research and educational use under the licences set out below.

## Measurement data

The two tables under `data/` come from *A Catalogue of British Bronze Age Axeheads, Including Basic Typology, Compositional Analyses and Associated Radiocarbon Dates*, deposited with the Archaeology Data Service (DOI [10.5284/1122315](https://doi.org/10.5284/1122315)) and described in its data paper in the Journal of Open Archaeology Data (DOI [10.5334/joad.119](https://doi.org/10.5334/joad.119)). The archive is published under a **Creative Commons Attribution 4.0 (CC BY 4.0)** licence. `ADS_earlyaxes_elemental.tsv` holds the elemental compositions used as the UMAP input, and `ADS_earlyaxes_main.tsv` holds the object metadata (type, period, holding museum, accession number). When reusing the measurements, cite the ADS deposit above.

## Photographs

The 121 photographs under `axe_photos/` are all from the British Museum's online collection, served from its open media CDN. British Museum collection images are published under a **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0)** licence, credited "© The Trustees of the British Museum". They are reproduced here, resized to thumbnail resolution, for non-commercial research and educational illustration of the analytical method. Under the share-alike term, these resized images remain under CC BY-NC-SA 4.0. The per-image source is recorded in `bm_image_manifest.csv`, each row giving the axe's `ArtefactID`, its British Museum accession, and the object and image URLs it was taken from, so any image can be traced back to its catalogue record.

The three section-header images under `banners/` come from a separate, more permissive source: Wikimedia Commons. They show a flanged axe, a palstave, and a socketed axe, illustrating the three broad chronological forms. The two Portable Antiquities Scheme finds are credited to the recording scheme. The flanged axe is licensed **CC BY-SA 4.0** and the palstave **CC BY-SA 2.0**. The socketed axe is in the **public domain**. Each banner's caption in the notebook carries its individual credit and a link to the source file.

### Photographs that are not bundled

The example plots 539 axes. Of the 149 we could locate online, 28 are held not by the British Museum but by the Ashmolean Museum (14), National Museum Wales (8), and the Cambridge Museum of Archaeology and Anthropology (8). These are **not** included in this bundle, because their images are not openly licensed for redistribution: the Ashmolean and National Museum Wales reserve all rights and require permission for reproduction, and the Cambridge collection is licensed CC BY-NC-ND, whose no-derivatives term does not permit the resized copies used here. The axes themselves remain on the plot; they simply carry no bundled photograph. Their catalogue locations are still recorded, for reference, in `other_museum_manifest.csv`, and the plotted axes with no online photograph at all are listed in `axes_without_photos.csv` with a lookup URL where one exists.

## How the photographs were matched

`IMAGES.md` describes the matching method in full. In brief, each British Museum accession is resolved to its photograph through the museum's search API, accepting only a record whose unique object id matches the registration and whose object type is an axe, so a same-numbered non-axe object is never substituted. Every request is a plain HTTP call through a browser-impersonating client; no browser is launched or driven. The resolver is `fetch_bm_images.py`; `fetch_other_museum_images.py` is the resolver that was used for the other three museums and is retained here for provenance, though their images are not bundled.
